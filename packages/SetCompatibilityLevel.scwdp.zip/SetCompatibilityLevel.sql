DECLARE @sqlCommand nvarchar(1000)=''
DECLARE @NewLineChar AS CHAR(2) = CHAR(13) + CHAR(10)

select @sqlCommand = @sqlCommand + 'ALTER DATABASE ' + '[' + [Name] + ']' + ' SET COMPATIBILITY_LEVEL = 130'+@NewLineChar from sys.databases
where COMPATIBILITY_LEVEL<>130 and Name <> 'master'

EXEC sp_executesql @sqlCommand